//go:build required
// +build required

package vendor
