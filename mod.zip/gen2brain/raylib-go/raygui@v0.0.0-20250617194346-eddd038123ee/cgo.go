package raygui

/*
#cgo CFLAGS: -std=gnu99 -Wno-unused-result
*/
import "C"
