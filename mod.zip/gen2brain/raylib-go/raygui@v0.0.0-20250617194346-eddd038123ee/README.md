## raygui [![GoDoc](https://godoc.org/github.com/gen2brain/raylib-go/raygui?status.svg)](https://godoc.org/github.com/gen2brain/raylib-go/raygui)

raygui is simple and easy-to-use IMGUI (immediate mode GUI API) library.


### controls_test_suite

![Demo](../examples/gui/controls_test_suite/controls_test_suite.png)


### scroll_panel

![Demo](../examples/gui/scroll_panel/scroll_panel.png)
