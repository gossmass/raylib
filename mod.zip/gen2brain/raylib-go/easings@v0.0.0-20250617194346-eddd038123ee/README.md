## easings [![GoDoc](https://godoc.org/github.com/gen2brain/raylib-go/easings?status.svg)](https://godoc.org/github.com/gen2brain/raylib-go/easings)

Useful easing functions for values animation.

A port of Robert Penner's [easing equations](http://robertpenner.com/easing/).

![Demo](../examples/easings/easings/easings.gif)
